package controller.post;

public class ViewPostController {

}

package controller.post;

public class DeletePostController {

}

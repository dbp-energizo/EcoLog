package model;

public class BookMark {
	private String postNo;

	public BookMark() {} 	
	public BookMark(String postNo) {
		this.postNo = postNo;
	}
	 
	public String getPosNo() {
		return postNo;
	}
	public void setPosNo(String posNo) {
		this.postNo = posNo;
	} 	
	
}

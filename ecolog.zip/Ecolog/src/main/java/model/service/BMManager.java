package model.service;

public class BMManager {

	public static BMManager getInstance() {
		// TODO Auto-generated method stub		//아직 정의 X
		return null;
	}

	public void delete(String postNo) {
		// TODO Auto-generated method stub		//아직 정의 X
		
	}

}

package model.service;

import java.util.List;

import model.Post;

public class PostManager {

	public static PostManager getInstance() {
		// TODO Auto-generated method stub
		return null;
	}

	public void create(Post post) {
		// TODO Auto-generated method stub
		
	}

	public Post findPost(String postNo) {
		// TODO Auto-generated method stub
		return null;
	}

	public void update(Post updatePost) {
		// TODO Auto-generated method stub
		
	}

	public List<Post> findPostList() {
		// TODO Auto-generated method stub
		return null;
	}

	public void delete(String postNo) {
		// TODO Auto-generated method stub
		
	}
	
}

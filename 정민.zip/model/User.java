package model;

import java.util.List;

public class User {
	private String id;
	private String password;
	private String name;
	private String phone;
	private String email;
	private int address;
	private String birth;
	private String nickname;  
	private int point; 
	private List<Community> Community;
	private int regDate; 
	//private Character ch = new Character(id, nickname);
	private List<String> imageList;
	
	
	public User() {
		super();
	}

	public User(java.lang.String id, java.lang.String password, java.lang.String name, java.lang.String phone,
			java.lang.String email, int address, java.lang.String birth, java.lang.String nickname, int point,
			List<Community> Community, int regDate) {
		super();
		this.id = id;
		this.password = password;
		this.name = name;
		this.phone = phone;
		this.email = email;
		this.address = address;
		this.birth = birth;
		this.nickname = nickname;
		this.point = point;
		this.Community = Community;
		this.regDate = regDate;
	}

	/*public void update(User updateUser) {
        this.password = updateUser.password;
        this.name = updateUser.name;
        this.email = updateUser.email;
        this.phone = updateUser.phone;
    }*/
	

	public boolean matchPassword(String password) {
		if (password == null) {
			return false;
		}
		return this.password.equals(password);
	}
	
	public String getId() {
		return id;
	}

	public void setId(String id) {
		this.id = id;
	}

	public String getPassword() {
		return password;
	}

	public void setPassword(String password) {
		this.password = password;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getPhone() {
		return phone;
	}

	public void setPhone(String phone) {
		this.phone = phone;
	}

	public String getEmail() {
		return email;
	}

	public void setEmail(String email) {
		this.email = email;
	}

	public int getAddress() {
		return address;
	}

	public void setAddress(int address) {
		this.address = address;
	}

	public String getBirth() {
		return birth;
	}

	public void setBirth(String birth) {
		this.birth = birth;
	}

	public String getNickname() {
		return nickname;
	}

	public void setNickname(String nickname) {
		this.nickname = nickname;
	}

	public int getPoint() {
		return point;
	}

	public void setPoint(int point) {
		this.point = point;
	}

	public List<Community> getCommunity() {
		return Community;
	}

	public void setCommunity(List<Community> Community) {
		this.Community = Community;
	}

	public int getRegDate() {
		return regDate;
	}

	public void setRegDate(int regDate) {
		this.regDate = regDate;
	}

/*	public Character getCh() {
		return ch;
	}

	public void setCh(Character ch) {
		this.ch = ch;
	} */

	public List<String> getImageList() {
		return imageList;
	}

	public void setImageList(List<String> imageList) {
		this.imageList = imageList;
	}

	public boolean isSameUser(String userid) {
        return this.id.equals(userid);
    }

	@java.lang.Override
	public String toString() {
		return "user [id=" + id + ", password=" + password + ", name=" + name + ", phone=" + phone + ", email=" + email
				+ ", address=" + address + ", birth=" + birth + ", nickname=" + nickname + ", point=" + point
				+ ", regDate=" + regDate + "]";
	}
	
}
